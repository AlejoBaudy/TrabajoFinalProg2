const Usuarios= {
    usuario:
        {
            Email: "Wschuchner@udesa.edu.ar",
            Usuario: "Wilfredo",
            Contrasena: "Wildo1506",
            Fecha: "15/06/2006",
            DNI: 47346229,
            Foto: "/images/users/foto1.jpg"
        },
     productos: [{
        id: 1,
        Imagen: "/images/products/zapatillaBaskettres.jpg",
        Producto: "Zapatillas basket nike",
        Descripcion: "Zapatillas blancas",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Excelentes zapas!",
            imagenPerfil: "/images/users/Foto1.jpg"
         },
         {
            usuario: "Wilfredo Schucner",
            texto: "Gran remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         },
         {
            usuario: "Alejo Baudy",
            texto: "Muy buena calidad!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
    },{
        Imagen: "/images/products/remeraMiami.jpg",
        id: 2,
        Producto: "Remera Miami Heat",
        Descripcion: "Remera de los Miami Heat de muy buena calidad",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Excelente remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         },
         {
            usuario: "Wilfredo Schucner",
            texto: "Gran remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         },
         {
            usuario: "Alejo Baudy",
            texto: "Muy buena calidad!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/remeragolden.jpg",
        id: 3,
        Producto: "Remera de basket",
        Descripcion: "Remera de los Golden State",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Gran remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/shortrojo.jpg",
        id: 4,
        Producto: "Short de basket",
        Descripcion: " Short rojo Jordan",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Excelente cafetera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/pelota-basket.png",
        id: 5,
        Producto: "Pelota de basket",
        Descripcion: "Marca Wilson, de los Chicago Bulls",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Esta buenisima la pelota!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/camisetaLilard.jpg",
        id: 6,
        Producto: "Camiseta Damian Lillard",
        Descripcion: "Oficial",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Jugadorazo y excelente remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         },
         {
            usuario: "Wilfredo Schuchner",
            texto: "Muy buena calidad!",
            imagenPerfil: "/images/users/Foto1.jpg"
         },
         {
            usuario: "Alejo Baudy",
            texto: "Gran remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/remeraAll.jpg",
        id: 7,
        Producto: "Remera de basket",
        Descripcion: " Remera All Stars",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Gran remera!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/zapatillaBasketdos.jpg",
        id: 8,
        Producto: "Zapatillas de basket",
        Descripcion: "Zapatillas de basket Nike",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Muy buenas zapatillas, ahora meto mas puntos!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/conjuntoBulls.jpg",
        id: 9,
        Producto: "Conjunto Bulls",
        Descripcion: "Producto de basket",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Gran conjunto!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
        Imagen: "/images/products/camisetaBoston.jpg",
        id: 10,
        Producto: "Remera de los Boston",
        Descripcion: "Talle L",
        Comentarios: [
         {
            usuario: "Francisco Martini",
            texto: "Remeron!",
            imagenPerfil: "/images/users/Foto1.jpg"
         }
        ]
     },{
      Imagen: "/images/products/camisetaphoenix.jpg",
      id: 11,
      Producto: "Remera de los Phoenix",
      Descripcion: "Talle M",
      Comentarios: [
       {
          usuario: "Francisco Martini",
          texto: "Muy buena remera, gran calidad!",
          imagenPerfil: "/images/users/Foto1.jpg"
       }
      ]
   },{
      Imagen: "/images/products/camisetaboca.jpg",
      id: 12,
      Producto: "Remera de Boca",
      Descripcion: "Camiseta retro",
      Comentarios: [
       {
          usuario: "Francisco Martini",
          texto: "Muy buena remera, buenos detalles!",
          imagenPerfil: "/images/users/Foto1.jpg"
       }
      ]
   }],
        

 }
 module.exports= Usuarios